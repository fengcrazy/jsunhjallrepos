This directory contains a number of examples that show how to use
the C++/Tree mapping. The following list gives an overview of
each example. See the README files in example directories for
more information on each example.

hello
  A simple "Hello, world!" example that shows how to parse XML
  documents.

library
  Shows hot to handle more complicated data structures, use the
  ID/IDREF cross-referencing mechanism, use the xsd:enumeration
  to C++ enum mapping, modify the object model, and serialize
  the modified object model back to XML.

polymorphism
  Shows how to use XML Schema polymorphism features such as the
  xsi:type attribute and substitution groups.

xpath
  Shows how to use the C++/Tree mapping together with XPath.

wildcard
  Shows how to use the optional wildcard mapping to parse, access,
  modify, and serialize the XML data matched by XML Schema wildcards
  (any and anyAttribute).

mixed
  Shows how to access the underlying DOM nodes to handle raw, "type-
  less content" such as mixed content models, anyType/anySimpleType,
  and any/anyAttribute.

multiroot
  Shows how to handle XML vocabularies with multiple root elements.

caching
  Shows how to parse several XML documents while reusing the
  underlying XML parser and caching the schemas used for validation.

performance
  Measures the performance of parsing and serialization. This example
  also shows how to structure your code to achieve the maximum
  performance for these two operations.

custom/
  A collection of examples that show how to customize the C++/Tree
  mapping by using custom C++ classes instead of or in addition to
  the generated ones. See the accompanying README file for an
  overview of each example in this directory.

streaming
  Shows how to create an XML document by performing multiple
  serializations of its smaller parts. This can be useful when the
  document is too large to fit into memory or when the other end
  needs to start processing without waiting for the whole document
  (streaming).

binary/
  A collection of examples that show how to serialize the object model
  into a number of predefined and custom binary formats.

dbxml
  Shows how to use the C++/Tree mapping on top of the Berkeley DB
  XML embedded XML database.
